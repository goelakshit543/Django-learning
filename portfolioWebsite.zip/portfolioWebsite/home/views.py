from django.shortcuts import render,HttpResponse
from home.models import Contact

# Create your views here.
def home(request):
    # return HttpResponse("this is the response(/)")
    contesxt={
        "name":"harry",
        "course":'Django'
    }
    return render(request,'home.html',contesxt)
def about(request):
    return render(request,'about.html')
    # return HttpResponse("this is the response for about(/)")
def projects(request):
    return render(request,'projects.html')
    # return HttpResponse("this is the response for projects(/)")
def contact(request):
    if request.method=='POST':
        name = request.POST['name']
        email = request.POST['address']
        phone = request.POST['phone']
        desc = request.POST['desc']
        # print(name,email,phone,desc)
        ins=Contact(name=name,email=email,phone=phone,desc=desc)
        ins.save()
        print("Data had been written to the db")
    return render(request,'contact.html')
    # return HttpResponse("this is the response for contact(/)")